
<?php
	require_once('auth.php');
?>
<?php
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Student Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link rel="stylesheet" type="text/css" href="default.css" />
<link href="css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
		<li><a href="studenthome.php">Home</a></li>
			 <li><a href="uploadcredentials.php">Upload Credentials</a></li>
			<li><a href="viewprofile.php">View Profile</a></li>
			<li><a href="clearedstatus.php">Cleared Status</a></li>
			<li><a href="viewmessage.php">View Message</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
	
	<div class="content">

<div style="padding:10px;">
  
  <h2>Student Details &raquo; Edit Details</h2>
			<hr />
			
				
				<?php
			$StudentID = $_GET['StudentID'];
			$sql = mysqli_query($connection, "SELECT * FROM tblStudent WHERE StudentID='$StudentID'");
			if(mysqli_num_rows($sql) == 0){
				header("Location: viewprofile.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			}
			if(isset($_POST['save'])){$StudentID		     = $_POST['StudentID'];
				$lastname	 = $_POST['lastname'];
				$firstname	 = $_POST['firstname'];
				$sex		     = $_POST['sex'];
				$phoneno		 = $_POST['phoneno'];
				$matricno		 = $_POST['matricno'];
				$programme			 = $_POST['programme'];
				$department		 = $_POST['department'];
				$faculty	         = $_POST['faculty'];
				
				$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	$image_name= addslashes($_FILES['image']['name']);
	$image_size= getimagesize($_FILES['image']['tmp_name']);

			
			move_uploaded_file($_FILES["image"]["tmp_name"],"Photos/" . $_FILES["image"]["name"]);			
			$location="Photos/" . $_FILES["image"]["name"];
				
				$update = mysqli_query($connection, "UPDATE tblStudent SET Lastname='$lastname', Firstname='$firstname', Gender='$sex', ContactNo='$phoneno', MatricNo='$matricno', Programme='$programme', Department='$department', Faculty='$faculty', Photo='$location' WHERE StudentID='$StudentID'") or die(mysqli_error());
				if($update){
					header("Location: edit.php?StudentID=".$StudentID."&message=success");
				}else{
					echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data could not be saved, please try again.</div>';
				}
			}
			
			if(isset($_GET['message']) == 'success'){
				echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data successfully saved.</div>';
			}
			?>
				
				
				<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
				
				<input type="hidden"  name="StudentID" value="<?php echo $row ['StudentID']; ?>" />
				
				
				
				<div class="form-group">
					<label class="col-sm-3 control-label"></label>
					<div class="col-sm-4">
						<?php echo '<p><img height="60" width="80" src="'.$row['Photo'].'"></p>';?>
						<input type="file" name="image"/> 
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-3 control-label">Surname :</label>
					<div class="col-sm-4">
						<input type="text" name="lastname" value="<?php echo $row ['Lastname']; ?>" class="form-control" placeholder="Lastname" required>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-3 control-label">Firstname :</label>
					<div class="col-sm-4">
						<input type="text"  name="firstname" value="<?php echo $row ['Firstname']; ?>" class="form-control" placeholder="Firstame" required>
					</div>
				</div>
				

<div class="form-group">
					<label class="col-sm-3 control-label">Sex</label>
					<div class="col-sm-2">
						<select name="sex" class="form-control" required>
							<option value=""> ----- </option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
                          
						</select>
					</div>
				

<div class="col-sm-3">
                    <b>Sex Selected :</b> <span class="label label-success"><?php echo $row['Gender']; ?></span>
				    </div>
				</div>

				
				<div class="form-group">
					<label class="col-sm-3 control-label">Phone No</label>
					<div class="col-sm-3">
						<input type="text"  name="phoneno" value="<?php echo $row ['ContactNo']; ?>" class="form-control" placeholder="Phone No" required>
					</div>
				</div>
				
				
				<div class="form-group">
					<label class="col-sm-3 control-label">Matric No</label>
					<div class="col-sm-4">
						<input type="text"  name="matricno" value="<?php echo $row ['MatricNo']; ?>" class="form-control" placeholder="Matric No" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Programme</label>
					<div class="col-sm-4">
						<input type="text"  name="programme" value="<?php echo $row ['Programme']; ?>" class="form-control" placeholder="Programme" required>
					</div>
				</div>




<div class="form-group">
					<label class="col-sm-3 control-label">Department</label>
					<div class="col-sm-4">
						<input type="text"  name="department" value="<?php echo $row ['Department']; ?>" class="form-control" placeholder="Department">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Faculty</label>
					<div class="col-sm-3">
						<input type="text"  name="faculty" value="<?php echo $row ['Faculty']; ?>" class="form-control" placeholder="Department">
					</div>
				</div>
				
<div class="form-group">
					<label class="col-sm-3 control-label">&nbsp;</label>
					<div class="col-sm-6">
						<input type="submit" name="save" class="btn btn-sm btn-primary" value="Update">
						<a href="records.php" class="btn btn-sm btn-danger">Cancel</a>
					</div>
				</div>
			</form>
  
</div>


</div>

	<div id="footer">
			<div class="left" ><h4>&copy; 2019 Online student clearance system.</h4></div>
			
	</div>
	
</div>
</body>
</html>
