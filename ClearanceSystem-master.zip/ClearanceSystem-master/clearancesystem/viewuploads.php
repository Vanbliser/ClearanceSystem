

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Student Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link rel="stylesheet" type="text/css" href="default.css" />

</head>
<body>


<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
			<li><a href="uploadcredentials.php">Upload Credentials</a></li>
			<li><a href="viewuploads.php">View Uploads</a></li>
			<li><a href="clearedstatus.php">Cleared Status</a></li>
			<li><a href="viewmessage.php">View Message</a></li>
		</ul>
	</div>
	
	<div class="content">

<div class="primary">
  <div class="prod_box_big">
  
  <div class="top_prod_box_big"></div>
  
  <div class="center_prod_box_big">  
  
<style type="text/css">
        body
        {
            font-family: Arial;
            font-size: 10pt;
        }
        th
        {
            background-color: #efefef;
        }
    </style>
<div></div>
<div class="product_title_big">Uploaded Credentials</div>

<table width="600" cellpadding="4" cellspacing="2" border="1">
<tr>
                <th colspan="2">
                    Uploaded File
                </th>
            </tr>
            <tr valign="top">
                <td>
                    <span id="ctl00_ContentPlaceHolder1_lblname" style="color:Green;">departmental.JPG<br />hostel.JPG<br />Library.JPG<br />medical.JPG<br />sports.JPG<br />student account.JPG<br />Student Affairs.JPG<br />workshop.JPG<br /></span>
                </td>
                <td>
                    <span id="ctl00_ContentPlaceHolder1_lbldb" style="color:Green;"><a target=_blank href=UserDocuments/c7e80f0b-43f5-4341-9e92-3133ebc7c394.JPG>c7e80f0b-43f5-4341-9e92-3133ebc7c394.JPG</a><br /><a target=_blank href=UserDocuments/2567cbdc-d40b-419a-8b32-b580f5abbfdb.JPG>2567cbdc-d40b-419a-8b32-b580f5abbfdb.JPG</a><br /><a target=_blank href=UserDocuments/3b13d4be-82cd-4ada-a609-3b5b1ae682ef.JPG>3b13d4be-82cd-4ada-a609-3b5b1ae682ef.JPG</a><br /><a target=_blank href=UserDocuments/fd2cb760-4b1e-4942-aee8-f14c49da7351.JPG>fd2cb760-4b1e-4942-aee8-f14c49da7351.JPG</a><br /><a target=_blank href=UserDocuments/f9e1f974-352a-4d56-9ca2-e00b3ce117d9.JPG>f9e1f974-352a-4d56-9ca2-e00b3ce117d9.JPG</a><br /><a target=_blank href=UserDocuments/6b5a7a59-d322-4775-949c-a6afce367ce9.JPG>6b5a7a59-d322-4775-949c-a6afce367ce9.JPG</a><br /><a target=_blank href=UserDocuments/da2dc671-a16b-4006-b547-393ab8f926a5.JPG>da2dc671-a16b-4006-b547-393ab8f926a5.JPG</a><br /><a target=_blank href=UserDocuments/be0f36b9-3c03-4675-963d-278526ed602e.JPG>be0f36b9-3c03-4675-963d-278526ed602e.JPG</a><br /></span>
                </td>
            </tr>

</table>
  
  
  

    </div> 
   <div class="bottom_prod_box_big"></div>
  </div>   
  
</div>

<div class="secondary">

<div id="ctl00_Panel1" style="height:160px;">
	
                
         <div class="title_box">Menu</div>
    
        <ul class="left_menu">
         <li class="odd"><a href="viewprofile.php">View Profile</a></li>
         <li class="even"><a href="uploadcredentials.php">Upload Credentials</a></li>
        <li class="odd"><a href="viewuploads.php">View Uploads</a></li>
        <li class="even"><a href="viewmessage.php">View Message</a></li>
        <li class="odd"><a href="clearedstatus.php">Cleared Status</a></li>
         <li class="even"> <a id="ctl00_LinkButton1" href="javascript:__doPostBack('ctl00$LinkButton1','')" style="color:Red;font-family:Calibri;font-size:Medium;font-weight:bold;">Logout</a></li>
        </ul>   
                
               
        
</div>


</div>
</div>

	<div id="footer">
			<div class="left"><h2>&copy; 2019 Online Student Clearance System.</h2></div>
			<div class="right"></div>
	</div>
	
</div>
</body>
</html>
