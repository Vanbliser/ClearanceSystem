

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="stylesheet" type="text/css" href="default.css" />
</head>
<body>

<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	
	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="register.php" class="active">Register</a></li>
			<li><a href="aboutprogram.php">About</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="admin.php">AdminLogin</a></li>
		</ul>
	</div>
	
	
	<div id="logincontent">  
    <div class="in1">
                    <div class="in2">
                        
                        <table width="100%" cellspacing="5" cellpadding="5" border="0">
                            <tbody>
                            <tr>
                                
                                <td width="76%" class="">
                                    <div style="border-radius: 5px 5px 5px 5px; padding: 5px 5px 5px 5px; border: thin solid #EDF4F9;">
                                        <div style="width:100%; ">
                                           
    
    <section id="loginForm">
        <h2>Admin Login</h2>
        
        
                <style>
                    ol li, ol { list-style-type:none;
                    }
                </style>
                <form action="adminlogin.php" method="post" >
                <fieldset>
                    <legend></legend>
                    <ol class="no-bullet">
                        <li>
                            <label for="ContentPlaceHolder1_ctl00_UserName">Username</label>
                            <input name="user" type="text" id="username" style="height:20px; width:208px" />
        
                           
                        </li>
                        <li>
                            <label for="ContentPlaceHolder1_ctl00_Password">Password</label>
                            <input name="password" type="password" id="Password" style="height:20px; width:208px" />
                            
                        </li>
                       
                    </ol>
                    <p style="margin-left:250px;">
                   <input type="submit" name="login" value="Login" id="Transfer" />
                   
                   <input type="submit" name="Reset" value="Cancel" id="Reset" /> 
                   
        
                   </p>
        
                </fieldset>
            </form>
            
        
    </section>

                                        </div>
                                    </div>
                                </td>
                               
                            </tr>
                        </tbody></table>
                    </div>
                </div>
 

</div>

	<div id="footer">
			<div class="left"><h2>&copy; 2019 Online Student Clearance System.</h2></div>
			<div class="right"></div>
	</div>
	
</div>

</body>
</html>

