<?php
include("connection.php");
?>

<?php
			if(isset($_POST['send'])){
				$username		     = $_POST['username'];
				$message		     = $_POST['message'];
                              

				
					
						$insert = mysqli_query($connection, "INSERT INTO Message(Username, MessageDetails)
															VALUES('$username','$message')") or die(mysqli_error());
						if($insert){
							echo '<script type="text/javascript">alert("Message was sent successfully!! "); window.location = "clearstudents.php";</script>';
						}else{
							echo '<script type="text/javascript">alert("Message was not sent !! "); window.location = "clearstudents.php";</script>';
						}
					
				
			}
			?>