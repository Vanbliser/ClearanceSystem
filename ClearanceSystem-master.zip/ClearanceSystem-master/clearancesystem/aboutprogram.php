

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="stylesheet" type="text/css" href="default.css" />

</head>
<body>

<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>
	
	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="register.php">Register</a></li>
			<li><a class="active" href="aboutprogram.php">About</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="admin.php">Admin Login</a></li>
		</ul>
	</div>
	
	<div id="logincontent">
<div style="border: 1px solid #e2e2e6; padding:10px;">
   <br />
  <h2> Development of an school fees payments and online student clearance system</h1>
  <br />
   <p> This program eliminates the current clearance system of the university which is a manual one. This manual system is so tedious and time consuming.  Here, students have to visit all the clearance offices with a form for them to sign. Once these forms are signed, it proves that the student has been cleared. This process takes some months to be completed and posses a lot of stress to both staff and students involved.</p>
   <p> With this new system, the tedious nature of clearance will be reduced. Final year students can get cleared by scanning all relevant receipts and uploading it.</p>

</div>

</div>

	<div id="footer">
			<div class="left" ><h4>&copy; 2019 Online student clearance system.</h4></div>
			
	</div>
	
</div>

</body>
</html>

