
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="stylesheet" type="text/css" href="default.css" />

</head>
<body>

<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>
	
	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="register.php">Register</a></li>
			<li><a href="aboutprogram.php">About</a></li>
			<li><a class="active" href="contact.php">Contact</a></li>
			<li><a href="admin.php">Admin Login</a></li>
		</ul>
	</div>

	
	<div id="logincontent">

<div style="border: 1px solid #e2e2e6; padding:10px;">
<br />
  <h2> Development of an online clearance for graduating student </h2><br />
 
 
  
</div>

</div>

	<div id="footer">
			<div class="left" ><h4>&copy; 2019 Online student clearance system.</h4></div>
			
	</div>
	
</div>

</body>
</html>

