
<?php
	require_once('auth.php');
?>
<?php 
include ('uplconnection/connect.php');


require("uplconnection/opener_db.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Student Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link rel="stylesheet" type="text/css" href="default.css" />
<script type="text/javascript" src="js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/bootstrap-button.js"></script>
<script type="text/javascript" src="js/jquery.wordcount.js"></script>
<link href="js/bootstrap.min.css" rel="stylesheet" type="text/css" />

<script>
      function countChar(val) {
      	var max = 40;
        var len = val.value.length;
        if (len >= max) {
          val.value = val.value.substring(0, 40);
          $('#charNum').text('You have reached the limit');
        } else {
          var char = max - len;
          $('#charNum').text(char + ' characters left');
        }
     };      
</script>

<script>
      function countChar1(val) {
      	var max = 90;
        var len = val.value.length;
        if (len >= max) {
          val.value = val.value.substring(0, 90);
          $('#charNum1').text('You have reached the limit');
        } else {
          var char = max - len;
          $('#charNum1').text(char + ' characters left');
        }
     };      
</script>
</head>

<body>

<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
		    <li><a href="uploadcredentials.php">Upload Credentials</a></li>
			<li><a href="viewprofile.php">View Profile</a></li>
			<li><a href="clearedstatus.php">Cleared Status</a></li>
			<li><a href="viewmessage.php">View Message</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
	
	<div class="content">

<div style="padding:10px;" >


  <br /><br />
  
<hr style="border-color: #d8d8d8;" />
 <div class="status" style="width:100%;" align="center">
        <?php
	if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
		echo "<ul class='error'> ";
		foreach($_SESSION['ERRMSG_ARR'] as $msg) {
			echo '<li> <strong><font color="red">',$msg ,'</font></strong></li>'; 
		}echo "</ul>";
		unset($_SESSION['ERRMSG_ARR']);
	}
?> 
</div> 


<div style="width:100%; margin:5px;" align="center">
<form action="upload.php" method="post" enctype="multipart/form-data" name="upload" style="margin:5px;">
<label><h3>File Uploader Module</h3> </label><br/>
<label>File Name : </label>
<input type="text" name="fname" class="form-control" placeholder="File Name" onkeyup='countChar(this)' autocomplete="false" required/><label id='charNum' style="color: blue;"></label><br />
<label> Description</label>
<textarea name="desc" cols="" rows="" class="input-xlarge" onkeyup='countChar1(this)' required></textarea><label id='charNum1' style="color: blue;"></label><br />
<label>File Uploader : </label>
<?php 
	echo $_SESSION['SESS_NAME'];
?>
<br />

<input name="uploaded_file" type="file" class="input-xlarge" required/>
<input type="hidden" name="MAX_FILE_SIZE" value="1000000" />
<br /><br />
<input name="Upload" type="submit" value="Upload" class="btn btn-primary" />
</form>
</div>

<hr style="border-color: #d8d8d8;" />

<div>
<input type="button" value="Back" class="btn btn-primary" onclick="window.open('uploadcredentials.php','_self');" />&nbsp;

</div>


  </div>   
  
</div>


</div>

	<div id="footer">
			<div class="left"><p>&copy; 2019 Online Student Clearance System.</p></div>
			<div class="right"></div>
	</div>
	
</div> 
</body>
</html>
