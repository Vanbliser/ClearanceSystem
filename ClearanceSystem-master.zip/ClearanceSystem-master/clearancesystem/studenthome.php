
<?php
	require_once('auth.php');
?>
<?php
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Student Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link rel="stylesheet" type="text/css" href="default.css" />
<link href="css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
		<li><a href="studenthome.php">Home</a></li>
			 <li><a href="uploadcredentials.php">Upload Credentials</a></li>
			<li><a href="viewprofile.php">View Profile</a></li>
			<li><a href="clearedstatus.php">Cleared Status</a></li>
			<li><a href="viewmessage.php">View Message</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
	
	<div class="content">

<div style="padding:10px;">
  
  
  <center><h2>Welcome to your school fee payments and clearance portal</h2></center>
  
  
  <h3>Instructions on how to use the portal</h3>
  <br/>
  
  <ul>
  <br/>
  <li>1. Make sure you have scanned your various receipts and/or tellers</li>
  <br/>
  <li>2. Rename your scanned documents accordingly (e.g school fees receipt, library fines, medical fees e.t.c)</li>
  <br/>
  <li>3. Click the UPLOAD CREDENTIALS link and upload your scanned receipts </li>
  <br/>
  <li>4. When your receipts have been reviewed, you will be cleared</li>
  <br/>
  <li>5. To check if you have been cleared, click the CLEARED STATUS link, to check your status</li>
  
  <br/>
  <li>6. To check if you have any message from admin, click the VIEW MESSAGE link, to check your messages</li>
  
  </ul>
  
     
  
</div>


</div>

	<div id="footer">
			<div class="left" ><h4>&copy; 2019 Online student clearance system.</h4></div>
			
	</div>

</div>
</body>
</html>
