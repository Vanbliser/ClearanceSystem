<?php
	require_once('auth.php');
?>
<?php
include("connection.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Student Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link rel="stylesheet" type="text/css" href="default.css" />
<link href="css/bootstrap.min.css" rel="stylesheet">

</head>
<body>


<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
		 <li><a href="studenthome.php">Home</a></li>
			 <li><a href="uploadcredentials.php">Upload Credentials</a></li>
			<li><a href="viewprofile.php">View Profile</a></li>
			<li><a href="clearedstatus.php">Cleared Status</a></li>
			<li><a href="viewmessage.php">View Message</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
	
	<div class="content">

<div style="padding:10px;" >
    
			<h2>Record &raquo; Profile</h2>
			<hr />
			
			<?php
			$username=$_SESSION['SESS_NAME'];
			
			$sql = mysqli_query($connection, "SELECT * FROM tblStudent WHERE Username='$username'");
			if(mysqli_num_rows($sql) == 0){
							echo '<script type="text/javascript">alert("Record not found "); window.location = "studenthome.php";</script>';

				//header("Location: records.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			}
			
			?>
			
			<table class="table table-striped table-condensed">
				<tr>
					<th width="20%"></th>
					<td><?php echo '<p><img height="60" width="80" src="'.$row['Photo'].'"></p>';?></td>
				</tr>
				<tr>
					<th>Lastname</th>
					<td><?php echo $row['Lastname']; ?></td>
				</tr>
				
				<tr>
					<th>Firstname</th>
					<td><?php echo $row['Firstname']; ?></td>
				</tr>
				
				<tr>
					<th>Sex</th>
					<td><?php echo $row['Gender']; ?></td>
				</tr>
				<tr>
					<th>Phone No</th>
					<td><?php echo $row['ContactNo']; ?></td>
				</tr>
				<tr>
					<th>Matric No</th>
					<td><?php echo $row['MatricNo']; ?></td>
				</tr>
				
				<tr>
					<th>Programme</th>
					<td><?php echo $row['Programme']; ?></td>
				</tr>
				<tr>
					<th>Department</th>
					<td><?php echo $row['Department']; ?></td>
				</tr>
				<tr>
					<th>Faculty</th>
					<td><?php echo $row['Faculty']; ?></td>
				</tr>
				
			</table>
			
			<a href="studenthome.php" class="btn btn-sm btn-info"><span class="glyphicon glyphicon-refresh" aria-hidden="true"></span> Back</a>
			<a href="edit.php?StudentID=<?php echo $row['StudentID']; ?>" class="btn btn-sm btn-success"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> Edit Data</a>
			
		
	 
  
</div>


</div>

	<div id="footer">
			<div class="left" ><h4>&copy; 2019 Online student clearance system.</h4></div>
			
	</div>
	
</div>
</body>
</html>
