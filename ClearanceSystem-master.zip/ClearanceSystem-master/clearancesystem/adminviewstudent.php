<?php
	require_once('auth.php');
?>
<?php
include("connection.php");
?>

<?php 
include ('uplconnection/connect.php');

require("uplconnection/opener_db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Clearance System</title>

	<!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-datepicker.css" rel="stylesheet">
	
	
	
	<style>
		.content {
			margin-top: 80px;
		}
	</style>
	
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand visible-xs-block visible-sm-block" href="home.php">Online Clearance System</a>
				<a class="navbar-brand hidden-xs hidden-sm" href="home.php"></a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li class="active"><a href="clearstudents.php">Clearance</a></li>
					
					<li class="active"><a href="viewregisteredstudents.php">Registered Students</a></li>
					
					
					
					<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Settings <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <!-- <li><a href="#">Reports</a></li> -->
              <!--   <li><a href="#">Others</a></li> -->
                <li><a href="logout.php">Logout</a></li>
              </ul>  
            </li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</nav>
	<div class="container">
		<div class="content">
			<h2>Student Details &raquo; Clear Student</h2>
			<hr />
			
			<?php
			$StudentID = $_GET['StudentID'];
			$sql = mysqli_query($connection, "SELECT * FROM tblStudent WHERE StudentID='$StudentID'");
			if(mysqli_num_rows($sql) == 0){
				header("Location: clearstudents.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			}
			$fuplder = $row ['Username'];
			
					
			if(isset($_POST['save'])){
			
			
			 $str='';
foreach ($_POST['section'] as $val)
{
    $str.=$val.',';
}

$str=substr($str,0,-1);
			
			
	$update = mysqli_query($connection, "UPDATE up_files SET Approval='$str' WHERE fuplder='$fuplder'") or die(mysqli_error());
				if($update){
					header("Location: adminviewstudent.php?StudentID=".$StudentID."&message=success");
				}else{
					echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data could not be saved, please try again.</div>';
				}
	

			
			
			}
			
			if(isset($_GET['message']) == 'success'){
				echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Data successfully saved.</div>';
			}
			?>
			
			
			<?php
			$StudentID = $_GET['StudentID'];
			$sql = mysqli_query($connection, "SELECT * FROM tblStudent WHERE StudentID='$StudentID'");
			if(mysqli_num_rows($sql) == 0){
				header("Location: clearstudents.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			}
			$fuplder = $row ['Username'];
			
			$sqll = mysqli_query($connection, "SELECT Approval FROM up_files WHERE fuplder='$fuplder'");
			if(mysqli_num_rows($sqll) == 0){
			echo '<script type="text/javascript">alert("This student has not uploaded any credentials "); window.location = "clearstudents.php";</script>';
				//header("Location: clearstudents.php");
			}else{
				$roww = mysqli_fetch_assoc($sqll);
			}
			
			$Approval=explode(",",$roww['Approval']);
		
			?>
			
			<form class="form-horizontal" action="" method="post">
				
				<input type="hidden"  name="StudentID" value="<?php echo $row ['StudentID']; ?>" />
				
				
				
				<div class="form-group">
					<label class="col-sm-3 control-label"></label>
					<div class="col-sm-4">
						<?php echo '<p><img height="60" width="80" src="'.$row['Photo'].'"></p>';?>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-3 control-label">Surname :</label>
					<div class="col-sm-4">
						<input type="text" disabled="disabled" name="lastname" value="<?php echo $row ['Lastname']; ?>" class="form-control" placeholder="Lastname" required>
					</div>
				</div>
				
				<div class="form-group">
					<label class="col-sm-3 control-label">Firstname :</label>
					<div class="col-sm-4">
						<input type="text" disabled="disabled" name="firstname" value="<?php echo $row ['Firstname']; ?>" class="form-control" placeholder="Firstame" required>
					</div>
				</div>
				

<div class="form-group">
					<label class="col-sm-3 control-label">Sex :</label>
					<div class="col-sm-4">
						<span class="label label-success"><?php echo $row['Gender']; ?></span>
					</div>
				</div>

				
				<div class="form-group">
					<label class="col-sm-3 control-label">Phone No</label>
					<div class="col-sm-3">
						<input type="text" disabled="disabled" name="phoneno" value="<?php echo $row ['ContactNo']; ?>" class="form-control" placeholder="Phone No" required>
					</div>
				</div>
				
				
				<div class="form-group">
					<label class="col-sm-3 control-label">Matric No</label>
					<div class="col-sm-4">
						<input type="text" disabled="disabled" name="matricno" value="<?php echo $row ['MatricNo']; ?>" class="form-control" placeholder="Matric No" required>
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Programme</label>
					<div class="col-sm-4">
						<input type="text" disabled="disabled" name="programme" value="<?php echo $row ['Programme']; ?>" class="form-control" placeholder="Programme" required>
					</div>
				</div>




<div class="form-group">
					<label class="col-sm-3 control-label">Department</label>
					<div class="col-sm-2">
						<input type="text" disabled="disabled" name="department" value="<?php echo $row ['Department']; ?>" class="form-control" placeholder="Department">
					</div>
				</div>
				<div class="form-group">
					<label class="col-sm-3 control-label">Faculty</label>
					<div class="col-sm-3">
						<input type="text" disabled="disabled" name="faculty" value="<?php echo $row ['Faculty']; ?>" class="form-control" placeholder="Department">
					</div>
				</div>
				


				
				
			
			
		<hr style="border-color: #d8d8d8;" />
<h2>Uploaded Credentials</h2>
		
			
			<table class="table table-striped table-hover">
				<tr>
                    <th>No</th>
					<th>ID</th>
					<th>Filename</th>
<th>File Description</th>
<th>File</th>
					
<th>Tools</th>
             
				</tr>
				<?php
				
				$StudentID = $_GET['StudentID'];
			$sqll = mysqli_query($connection, "SELECT * FROM tblStudent WHERE StudentID='$StudentID'");
			if(mysqli_num_rows($sql) == 0){
				header("Location: clearstudents.php");
			}else{
				$row = mysqli_fetch_assoc($sqll);
			}
				$fuplder = $row ['Username'];
				
				$sql = mysqli_query($connection, "SELECT * FROM  up_files WHERE fuplder='$fuplder' ORDER BY id ASC");
				
				if(mysqli_num_rows($sql) == 0){
					echo '<tr><td colspan="8">No Record</td></tr>';
				}else{
					$no = 1;
					while($row = mysqli_fetch_assoc($sql)){
						echo '
						<tr>
							<td>'.$no.'</td>
							<td>'.$row['id'].'</td>
							<td>'.$row['fname'].'</td>
                            <td>'.$row['fdesc'].'</td>
							 <td>'.$row['floc'].'</td>
							  
                            
							<td>

								<a href="'.$row['floc'].'" title="View File" target="_blank" class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-download-alt" aria-hidden="true"></span></a>
								<a href="adminviewstudent.php?aksi=delete&id='.$row['id'].'" title="Delete Data" onclick="return confirm(\'Are you sure you want to delete this data with ID '.$row['id'].'?\')" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
							</td>
						</tr>
						';
						$no++;
					}
				}
				?>
			</table>
			
			
		<hr style="border-color: #d8d8d8;" />
<h2>Approve Student</h2>	
			
	
	<table class="table table-striped table-hover">
	<tr>
	<td><input type="checkbox" name="section[]" value="libraryfines" <?php if(in_array("libraryfines",$Approval)) { ?> checked="checked" <?php } ?> > Library Fines  </td>
	<td> <input type="checkbox" name="section[]" value="departmentalclearance" <?php if(in_array("departmentalclearance",$Approval)) { ?> checked="checked" <?php } ?> > Departmental Clearance </td>
	<td> <input type="checkbox" name="section[]" value="medicals" <?php if(in_array("medicals",$Approval)) { ?> checked="checked" <?php } ?> > Medicals </td>
	
	</tr>
	
	<tr>
	<td><input type="checkbox" name="section[]" value="hostelaccommodation" <?php if(in_array("hostelaccommodation",$Approval)) { ?> checked="checked" <?php } ?> > Hostel Accommodation  </td>
	<td> <input type="checkbox" name="section[]" value="examsandrecords" <?php if(in_array("examsandrecords",$Approval)) { ?> checked="checked" <?php } ?> >Exams and Records </td>
	<td> <input type="checkbox" name="section[]" value="studentaccounts" <?php if(in_array("studentaccounts",$Approval)) { ?> checked="checked" <?php } ?> >Student Accounts  </td>
	
	</tr>
	
	<tr>
	<td><input type="checkbox" name="section[]" value="studentaffairs" <?php if(in_array("studentaffairs",$Approval)) { ?> checked="checked" <?php } ?> > Student Affairs  </td>
	<td> <input type="checkbox" name="section[]" value="workshop" <?php if(in_array("workshop",$Approval)) { ?> checked="checked" <?php } ?> >Workshop </td>
	<td> <input type="checkbox" name="section[]" value="faculty" <?php if(in_array("faculty",$Approval)) { ?> checked="checked" <?php } ?> > Faculty </td>
	
	</tr>
	
	</table>
	
	
<hr style="border-color: #d8d8d8;" />
	
		
			<div class="form-group">
					<label class="col-sm-3 control-label">&nbsp;</label>
					<div class="col-sm-6">
						<input type="submit" name="save" class="btn btn-sm btn-primary" value="Update Student Clearance">
					</div>
				</div>
			
			
			</form>


			
			
			
<hr style="border-color: #d8d8d8;" />
<h2>Send Message to Student(If the student needs to rectify any issue) </h2>			
	
	
	<?php
			$SID = $_GET['StudentID'];
			$ressql = mysqli_query($connection, "SELECT * FROM tblStudent WHERE StudentID='$SID'");
			if(mysqli_num_rows($ressql) == 0){
				header("Location: clearstudents.php");
			}else{
				$resrow = mysqli_fetch_assoc($ressql);
			}
	?>
	<form class="form-horizontal" action="sendmessage.php" method="post">			
	<div class="form-group">
	
	<input type="hidden"  name="username" value="<?php echo $resrow ['Username']; ?>" />
	
					<label class="col-sm-3 control-label">Message</label>
					<div class="col-sm-3">
						<textarea name="message" class="form-control" rows="2" cols="4" placeholder="Message"></textarea>
					</div>
				</div>		
			
		<div class="form-group">
					<label class="col-sm-3 control-label">&nbsp;</label>
					<div class="col-sm-6">
						<input type="submit" name="send" class="btn btn-sm btn-primary" value="Send Message">
						<a href="clearstudents.php" class="btn btn-sm btn-danger">Cancel</a>
					</div>
				</div>
			
			
			</form>	
			

		</div>
	</div>

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
	$('.date').datepicker({
		format: 'yyyy-mm-dd',
	})
	</script>
</body>
</html>