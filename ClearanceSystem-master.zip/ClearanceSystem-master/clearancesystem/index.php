<?php
	//Start session
	session_start();
	
	//Unset the variables stored in session
	unset($_SESSION['SESS_ID']);
	unset($_SESSION['SESS_NAME']);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Student Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="stylesheet" type="text/css" href="default.css" />

<script type="text/javascript" src="xres/js/saslideshow.js"></script>
<script type="text/javascript" src="xres/js/slideshow.js"></script>

		<script type="text/javascript">
		$("#slideshow > div:gt(0)").hide();

		setInterval(function() { 
		  $('#slideshow > div:first')
			.fadeOut(1000)
			.next()
			.fadeIn(1000)
			.end()
			.appendTo('#slideshow');
		},  3000);
	</script>

</head>
<body>

<div id="upbg"></div>

<div id="outer">

     <div id="bgheader">
     
	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>
	<div id="hd">
	</div>
	
	</div>
	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
			<li><a class="active" href="index.php">Home</a></li>
			<li><a href="register.php">Register</a></li>
			<li><a href="aboutprogram.php">About</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="admin.php">Admin Login</a></li>
		</ul>
	</div>
	
	
	   <div id="rotator">
              <ul>
                    
                    <li class="show"><img src="xres/images/jb2/02.jpg" width="900" height="300"  alt="" /></li>
                    <li><img src="xres/images/jb2/03.jpg" width="900" height="300"  alt="" /></li>
                    <li><img src="xres/images/jb2/04.jpg" width="900" height="300"  alt="" /></li>
                    <li><img src="xres/images/jb2/06.jpg" width="900" height="300"  alt="" /></li>
                    <li><img src="xres/images/jb2/07.jpg" width="900" height="300"  alt="" /></li>
              </ul>
		</div>

	
	<div id="logincontent">
 

                         <br/>
                         <br/>
                        <table width="100%" cellspacing="5" cellpadding="5" border="0">
                            <tbody>
                            <tr>
                                
                                <td width="76%" class="">
                                    <div style="border-radius: 5px 5px 5px 5px; padding: 5px 5px 5px 5px; border: thin solid #7f8400;">
                                        <div style="width:100%; ">
                                           
    
    <section id="loginForm">
        <h2>Login</h2>
        
        
                <style>
                    ol li, ol { list-style-type:none;
                    }
                </style>
				
				<form action="login.php" method="post" >
                <fieldset>
                    <legend></legend>
                    <ol class="no-bullet">
                        <li>
                            <label for="ContentPlaceHolder1_ctl00_UserName">Username</label>
                            <input name="user" type="text" id="username" style="height:20px; width:208px" />
        
                           
                        </li>
                        <li>
                            <label for="ContentPlaceHolder1_ctl00_Password">Password</label>
                            <input name="password" type="password" id="Password" style="height:20px; width:208px" />
                            
                        </li>
                        <li>
                        <p>
                            Don't have an account? &nbsp;&nbsp;<a id="HyperLink1" href="check.php">Register Here</a>   
                        </p>
                        </li>
                    </ol>
                    <p style="margin-left:250px;">
                   <input type="submit" name="Transfer" value="Login" id="Transfer" />
                   
                   <input type="submit" name="Reset" value="Cancel" id="Reset" /> 
                   
        
                   </p>
        
                </fieldset>
            </form>
        
    </section>

                                        </div>
                                    </div>
                                </td>
                               
                            </tr>
                        </tbody></table>
            
   


</div>

	<div id="footer">
			<div class="left"><h2>&copy; Clearance System By IMT Group9</h2></div>
			<div class="right"></div>
	</div>
	
</div>

</body>
</html>
