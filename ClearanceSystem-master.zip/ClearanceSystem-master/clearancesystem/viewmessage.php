
<?php
	require_once('auth.php');
?>
<?php
include("connection.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Student Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link rel="stylesheet" type="text/css" href="default.css" />
<link href="css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
<li><a href="studenthome.php">Home</a></li>
			 <li><a href="uploadcredentials.php">Upload Credentials</a></li>
			<li><a href="viewprofile.php">View Profile</a></li>
			<li><a href="clearedstatus.php">Cleared Status</a></li>
			<li><a href="viewmessage.php">View Message</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
	
	<div class="content">

<div style="padding:10px;">
  
  
  <table class="table table-striped table-hover">
				<tr>
                    <th>No</th>
					<th>MessageID</th>
					<th>Message</th>
<th>Date and Time Sent</th>

             
				</tr>
				<?php
				
				$username=$_SESSION['SESS_NAME'];
				
				$sql = mysqli_query($connection, "SELECT * FROM  Message WHERE Username='$username' ORDER BY MessageID ASC");
				
				if(mysqli_num_rows($sql) == 0){
					echo '<tr><td colspan="8">No Record</td></tr>';
				}else{
					$no = 1;
					while($row = mysqli_fetch_assoc($sql)){
						echo '
						<tr>
							<td>'.$no.'</td>
							<td>'.$row['MessageID'].'</td>
							<td>'.$row['MessageDetails'].'</td>
                            <td>'.$row['ModifiedDate'].'</td>
													                             							
						</tr>
						';
						$no++;
					}
				}
				?>
			</table>
  
     
  
</div>


</div>

	<div id="footer">
			<div class="left" ><h4>&copy; 2019 Online student clearance system.</h4></div>
	
	</div>
	
</div>
</body>
</html>
