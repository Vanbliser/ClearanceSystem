<?php
	require_once('auth.php');
?>
<?php
include("connection.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content=""/>

<link rel="stylesheet" type="text/css" href="default.css" />
<link href="css/bootstrap.min.css" rel="stylesheet">

<script language="javascript">
function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=700, height=400, left=100, top=25"; 
  var content_vlue = document.getElementById("printsection").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('</head><body onLoad="self.print()" style="width: 700px; font-size:11px; font-family:arial; font-weight:normal;">');          
   docprint.document.write(content_vlue); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>


</head>
<body>


<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
		<li><a href="studenthome.php">Home</a></li>
			 <li><a href="uploadcredentials.php">Upload Credentials</a></li>
			<li><a href="viewprofile.php">View Profile</a></li>
			<li><a href="clearedstatus.php">Cleared Status</a></li>
			<li><a href="viewmessage.php">View Message</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
	
	<div class="content">

<div style="padding:10px;" >
    
			<h2>Record &raquo; Student Details</h2>
			<hr />
			
			<?php
			$username=$_SESSION['SESS_NAME'];
			
			$sql = mysqli_query($connection, "SELECT * FROM tblStudent WHERE Username='$username'");
			if(mysqli_num_rows($sql) == 0){
							echo '<script type="text/javascript">alert("Record not found "); window.location = "studenthome.php";</script>';

				//header("Location: records.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			}
			
			?>
			
			<table class="table table-striped table-condensed">
				<tr>
					<th width="20%"></th>
					<td><?php echo '<p><img height="60" width="80" src="'.$row['Photo'].'"></p>';?></td>
				</tr>
				<tr>
					<th>Lastname</th>
					<td><?php echo $row['Lastname']; ?></td>
				</tr>
				
				<tr>
					<th>Firstname</th>
					<td><?php echo $row['Firstname']; ?></td>
				</tr>
				
				<tr>
					<th>Sex</th>
					<td><?php echo $row['Gender']; ?></td>
				</tr>
				<tr>
					<th>Phone No</th>
					<td><?php echo $row['ContactNo']; ?></td>
				</tr>
				<tr>
					<th>Matric No</th>
					<td><?php echo $row['MatricNo']; ?></td>
				</tr>
				
				<tr>
					<th>Programme</th>
					<td><?php echo $row['Programme']; ?></td>
				</tr>
				<tr>
					<th>Department</th>
					<td><?php echo $row['Department']; ?></td>
				</tr>
				<tr>
					<th>Faculty</th>
					<td><?php echo $row['Faculty']; ?></td>
				</tr>
				
			</table>
			
			
			<?php
			
			$fuplder=$_SESSION['SESS_NAME'];
						
			$sqll = mysqli_query($connection, "SELECT Approval FROM up_files WHERE fuplder='$fuplder'");
			if(mysqli_num_rows($sqll) == 0){
			echo '<script type="text/javascript">alert("This student has not uploaded any credentials "); window.location = "studenthome.php";</script>';
				
			}else{
				$roww = mysqli_fetch_assoc($sqll);
			}
			
			$Approval=explode(",",$roww['Approval']);
		
			?>
			
			
				<hr style="border-color: #d8d8d8;" />
<h2>Sections Approved</h2>
			
			<table class="table table-striped table-hover">
	<tr>
	<td><input type="checkbox" disabled="disabled" name="section[]" value="libraryfines" <?php if(in_array("libraryfines",$Approval)) { ?> checked="checked" <?php } ?> > Library Fines  </td>
	<td> <input type="checkbox" disabled="disabled" name="section[]" value="departmentalclearance" <?php if(in_array("departmentalclearance",$Approval)) { ?> checked="checked" <?php } ?> > Departmental Clearance </td>
	<td> <input type="checkbox" disabled="disabled" name="section[]" value="medicals" <?php if(in_array("medicals",$Approval)) { ?> checked="checked" <?php } ?> > Medicals </td>
	
	</tr>
	
	<tr>
	<td><input type="checkbox" disabled="disabled" name="section[]" value="hostelaccommodation" <?php if(in_array("hostelaccommodation",$Approval)) { ?> checked="checked" <?php } ?> > Hostel Accommodation  </td>
	<td> <input type="checkbox" disabled="disabled" name="section[]" value="examsandrecords" <?php if(in_array("examsandrecords",$Approval)) { ?> checked="checked" <?php } ?> >Exams and Records </td>
	<td> <input type="checkbox" disabled="disabled" name="section[]" value="studentaccounts" <?php if(in_array("studentaccounts",$Approval)) { ?> checked="checked" <?php } ?> >Student Accounts  </td>
	
	</tr>
	
	<tr>
	<td><input type="checkbox" disabled="disabled" name="section[]" value="studentaffairs" <?php if(in_array("studentaffairs",$Approval)) { ?> checked="checked" <?php } ?> > Student Affairs  </td>
	<td> <input type="checkbox" disabled="disabled" name="section[]" value="workshop" <?php if(in_array("workshop",$Approval)) { ?> checked="checked" <?php } ?> >Workshop </td>
	<td> <input type="checkbox" disabled="disabled" name="section[]" value="faculty" <?php if(in_array("faculty",$Approval)) { ?> checked="checked" <?php } ?> > Faculty </td>
	
	</tr>
	
	</table>
		
	<hr style="border-color: #d8d8d8;" />
<h2>Cleared Status</h2>
<div style="text-align:center; font-size:36px;">
<?php 

if ( count($Approval) != 9)
{
echo '<span style=" color:red;">Not Cleared</span>';
}
else
{
 echo '<span style=" color:green;">Cleared</span>';
}


 ?>
 </div>

 
  
</div>
<br/>
<br/>

</div>

	<div id="footer">
			<div class="left" ><h4>&copy; 2019 Online student clearance system.</h4></div>
			
	</div>
	
</div>
</body>
</html>
