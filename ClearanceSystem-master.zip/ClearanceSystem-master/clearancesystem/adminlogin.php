<?php
	//Start session
	session_start();
	
	//Connect to mysql server
	include('reservation/connect.php');
	
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
	
	//Sanitize the POST values
	$login = clean($_POST['user']);
	$password = clean($_POST['password']);
    //$position = clean($_POST['position']);
	$result = mysql_query("SELECT * FROM user WHERE Username='$login' AND password='$password'");
	
	while($row = mysql_fetch_array($result))
		{
		$position = $row['position'];
		}
		
		if (empty($position)) {
		 echo '<script type="text/javascript">alert("Invalid Username and/or password"); window.location = "index.php";</script>';
		 return;
       }
	if ($position=='admin')
	{
		//Create query
		$qry="SELECT * FROM user WHERE Username='$login' AND password='$password'";
		$result=mysql_query($qry);
		//Check whether the query was successful or not
		if($result) {
			if(mysql_num_rows($result) > 0) {
				//Login Successful
				session_regenerate_id();
				$member = mysql_fetch_assoc($result);
				//$_SESSION['SESS_MEMBER_ID'] = $member['ID'];
				$_SESSION['SESS_NAME'] = $member['Username'];
				session_write_close();
				//if ($level="admin"){
				header("location: home.php");
				exit();
			}else {
				//Login failed
				header("location: index.php");
				exit();
			}
		}else {
			die("Query failed");
		}
	}
	?>