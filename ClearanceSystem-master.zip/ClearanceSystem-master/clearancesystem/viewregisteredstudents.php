<?php
	require_once('auth.php');
?>
<?php
include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Online Clearance System</title>

	<!-- Bootstrap -->
	<link href="css/bootstrap.min.css" rel="stylesheet">

	<style>
		.content {
			margin-top: 80px;
		}
	</style>

</head>
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand visible-xs-block visible-sm-block" href="home.php">Online Clearance System</a>
				<a class="navbar-brand hidden-xs hidden-sm" href="home.php"></a>
			</div>
			<div id="navbar" class="navbar-collapse collapse">
				<ul class="nav navbar-nav">
					<li class="active"><a href="clearstudents.php">Clearance</a></li>
					
					<li class="active"><a href="viewregisteredstudents.php">Registered Students</a></li>
					
					
					
					<li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Settings <b class="caret"></b></a>
              <ul class="dropdown-menu">
                <!-- <li><a href="#">Reports</a></li> -->
              <!--   <li><a href="#">Others</a></li> -->
                <li><a href="logout.php">Logout</a></li>
              </ul>  
            </li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</nav>
	<div class="container">
		
		<div class="content">
			<h2>Registered Students</h2>
			<hr />

			<?php
			if(isset($_GET['aksi']) == 'delete'){
				$StudentID = $_GET['StudentID'];
				$cek = mysqli_query($connection, "SELECT * FROM tblStudent WHERE StudentID='$StudentID'");
				if(mysqli_num_rows($cek) == 0){
					echo '<div class="alert alert-info alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Data not found</div>';
				}else{
					$delete = mysqli_query($connection, "DELETE FROM tblStudent WHERE StudentID='$StudentID'");
					if($delete){
						echo '<div class="alert alert-primary alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Data successfully removed.</div>';
	header("location: clearstudents.php");				

}else{
						echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Data failed to delete.</div>';
					}
				}
			}
			?>
<form class="form-inline" method="get">
				<div class="form-group">
					<select name="filter" class="form-control" onChange="form.submit()">
						<option value="0">Filter Records</option>
						<?php $filter = (isset($_GET['filter']) ? strtolower($_GET['filter']) : NULL);  ?>
						<option value="Computer Science" <?php if($filter == 'Computer Science'){ echo 'selected'; } ?>>Computer Science</option>
<option value="Electrical Electronics" <?php if($filter == 'Electrical Electronics'){ echo 'selected'; } ?>>Electrical Electronics</option>
<option value="Physics" <?php if($filter == 'Physics'){ echo 'selected'; } ?>>Physics</option>

                        
					</select>
				</div>
			</form>
			<br />
			<div class="table-responsive">
			<table class="table table-striped table-hover">
				<tr>
                    <th>No</th>
					<th>ID</th>
					<th>Lastname</th>
<th>Firstname</th>
<th>Matric No</th>
					<th>Faculty</th>
<th>Department</th>
<th>Contact No</th>
<th>Tools</th>
             
				</tr>
				<?php
				if($filter){
					$sql = mysqli_query($connection, "SELECT * FROM tblStudent WHERE Department='$filter' ORDER BY StudentID ASC");
				}else{
					$sql = mysqli_query($connection, "SELECT * FROM tblStudent ORDER BY StudentID ASC");
				}
				if(mysqli_num_rows($sql) == 0){
					echo '<tr><td colspan="8">No Record</td></tr>';
				}else{
					$no = 1;
					while($row = mysqli_fetch_assoc($sql)){
						echo '
						<tr>
							<td>'.$no.'</td>
							<td>'.$row['StudentID'].'</td>
							<td>'.$row['Lastname'].'</td>
                            <td>'.$row['Firstname'].'</td>
							 <td>'.$row['MatricNo'].'</td>
							  <td>'.$row['Faculty'].'</td>
							   <td>'.$row['Department'].'</td>
							   <td>'.$row['ContactNo'].'</td>
                            
							<td>

								<a href="viewregisteredstudents.php?aksi=delete&StudentID='.$row['StudentID'].'" title="Delete Student Data" onclick="return confirm(\'Are you sure you want to delete this student data with ID '.$row['StudentID'].'?\')" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash" aria-hidden="true"></span></a>
							</td>
						</tr>
						';
						$no++;
					}
				}
				?>
			</table>
			
			<div class="btn-group">
						  
						  <a href="home.php" class="btn btn-default"><span class="glyphicon glyphicon-circle-arrow-up"></span>  Back</a>
						  						</div>
			</div>
		</div>
		
		
	</div>
	<center>
	<p>&copy; Online Clearance System  2019</p
		></center>
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>
</html>
