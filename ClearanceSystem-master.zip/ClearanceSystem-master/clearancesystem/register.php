<?php
include("connection.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Student Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="stylesheet" type="text/css" href="default.css" />
</head>
<body>

<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	
	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="register.php" class="active">Register</a></li>
			<li><a href="aboutprogram.php">About</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li><a href="admin.php">Admin Login</a></li>
		</ul>
	</div>
	
	
	<div id="logincontent">
 
    <div style="border: 1px solid #e2e2e6;">
                    
 
    <section id="loginForm">
    <br />
        <h2>Register Here</h2>
        
        <br />
        
		
		<?php
			if(isset($_POST['add'])){
				$txtusername		     = $_POST['txtusername'];
                                $txtpassword		     = $_POST['txtpassword'];
				$txtlastname	 = $_POST['txtlastname'];
				$txtfirstname	 = $_POST['txtfirstname'];
				$sex		     = $_POST['sex'];
				$txtcontactno		 = $_POST['txtcontactno'];
				$txtmatricno		 = $_POST['txtmatricno'];
				$txtprogramme			 = $_POST['txtprogramme'];
				$txtdept		 = $_POST['txtdept'];
				$txtfaculty	         = $_POST['txtfaculty'];
$image= addslashes(file_get_contents($_FILES['image']['tmp_name']));
	$image_name= addslashes($_FILES['image']['name']);
	$image_size= getimagesize($_FILES['image']['tmp_name']);

			
			move_uploaded_file($_FILES["image"]["tmp_name"],"Photos/" . $_FILES["image"]["name"]);			
			$location="Photos/" . $_FILES["image"]["name"];
				
					
						$insert = mysqli_query($connection, "INSERT INTO tblStudent(Username,Password,Lastname,Firstname,Gender,ContactNo,MatricNo,Programme,Department,Faculty,Photo)
															VALUES('$txtusername', '$txtpassword', '$txtlastname', '$txtfirstname', '$sex', '$txtcontactno', '$txtmatricno', '$txtprogramme', '$txtdept','$txtfaculty', '$location')") or die(mysqli_error());
						if($insert){
							echo '<script type="text/javascript">alert("Record was saved successfully!!"); window.location = "register.php";</script>';
						}else{
							echo '<script type="text/javascript">alert("An error occured. Record was not saved!!"); window.location = "register.php";</script>';
						}
					
				
			}
			?>
		
		<form action="" method="post" enctype="multipart/form-data">
                <fieldset>
                    <legend></legend>
                   
                   <table cellpadding="5" cellspacing="5" border="0" width="450" align="center" style="margin:20px;">
                   
                   <tr>
                   <td><label for="Username">Username</label></td>
                   <td><input name="txtusername" type="text" id="txtusername" style="height:20px; width:208px" /></td>
                   </tr>
                   
                   
                   <tr>
                   <td><label for="Password">Password</label></td>
                   <td><input name="txtpassword" type="password" id="txtpassword" style="height:20px; width:208px" /></td>
                   </tr>
                   
                    <tr>
                   <td><label for="Lastname">Lastname</label></td>
                   <td><input name="txtlastname" type="text" id="txtlastname" style="height:20px; width:208px" /></td>
                   </tr>
                    
                   <tr>
                   <td><label for="Firstname">Firstname</label></td>
                   <td><input name="txtfirstname" type="text" id="txtfirstname" style="height:20px; width:208px" /></td>
                   </tr>
                   
                    <tr>
                   <td><label for="Sex">Sex</label></td>
                   <td><select name="sex" class="form-control" required>
							<option value=""> ----- </option>
							<option value="Male">Male</option>
							<option value="Female">Female</option>
                          
						</select></td>
                   </tr>
                   
                    <tr>
                   <td><label for="ContactNo">Contact No</label></td>
                   <td><input name="txtcontactno" type="text" id="txtcontactno" style="height:20px; width:208px" /></td>
                   </tr>
                   
                    <tr>
                   <td><label for="MatricNo">Matric No</label></td>
                   <td><input name="txtmatricno" type="text" id="txtmatricno" style="height:20px; width:208px" /></td>
                   </tr>
                   
                   
                    <tr>
                   <td><label for="Programme">Programme</label></td>
                   <td><input name="txtprogramme" type="text" id="txtprogramme" style="height:20px; width:208px" /></td>
                   </tr>
                   
                    <tr>
                   <td><label for="Department">Department</label></td>
                   <td> <input name="txtdept" type="text" id="txtdept" style="height:20px; width:208px" /></td>
                   </tr>
                    
                   <tr>
                   <td><label for="CFaculty">Faculty</label></td>
                   <td><input name="txtfaculty" type="text" id="txtfaculty" style="height:20px; width:208px" /></td>
                   </tr>
                   
                    <tr>
                   <td><label for="UploadPhoto">UploadPhoto</label></td>
                   <td><input type="file" name="image"/> </td>
                   </tr>
                   
                    <tr>
                   <td></td>
                   <td><input type="submit" name="add" value="Register" id="submit" />
                   
                   <input type="submit" name="Reset" value="Cancel" id="Reset" /> 
                   </td>
                   </tr>
                   
                   
                   </table> 
                  
                </fieldset>
            
        </form>
    </section>
                                   
                   
                </div>


</div>

	<div id="footer">
			<div class="left"><h2>&copy; 2019 Online Student Clearance System.</h2></div>
			<div class="right"></div>
	</div>
	
</div>

</body>
</html>

