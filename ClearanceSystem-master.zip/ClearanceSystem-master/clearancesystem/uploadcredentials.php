<?php
	require_once('auth.php');
?>
<?php 
include ('uplconnection/connect.php');

require("uplconnection/opener_db.php");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Online Student Clearance System</title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<link rel="stylesheet" type="text/css" href="default.css" />

<script type="text/javascript" src="js/jquery-1.8.2.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
<script type="text/javascript" src="js/bootstrap-button.js"></script>
<script type="text/javascript" src="js/page.js"></script>        
<script type="text/javascript" src="js/menu.js"></script>
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
		<script>
			function myfx(){
				var r = confirm('Are you sure you want to delete this file?');
				if (r == true) {
					window.open('uploadcredentials.php','_blank');    				
				} else {
    				alert('Delete Action Cancelled');	
				} 
			}	
		</script>

   
</head>

<body>

<div id="upbg"></div>

<div id="outer">


	<div id="header">
		<div id="headercontent">
		
		</div>
	</div>

	<div id="menu">
		<!-- HINT: Set the class of any menu link below to "active" to make it appear active -->
		<ul>
		<li><a href="studenthome.php">Home</a></li>
		    <li><a href="uploadcredentials.php">Upload Credentials</a></li>
			<li><a href="viewprofile.php">View Profile</a></li>
			<li><a href="clearedstatus.php">Cleared Status</a></li>
			<li><a href="viewmessage.php">View Message</a></li>
			<li><a href="logout.php">Logout</a></li>
		</ul>
	</div>
	
	<div class="content">

<div style="padding:10px;" >

  
  <br /><br />
  


<hr style="border-color: #d8d8d8;" />

<div align="center"><span class='table_headers'><h2 style="color: #f8f8f8;">Available Documents</h2></span></div>

<form action="" method="post">
<div id="container">
	<table border='2'>
      <div class="data"></div>
    </table>
      <div class="pagination"></div>
</div>  


<hr style="border-color: #d8d8d8;" />

<?php
@$id=$_POST['id']; 
@$btndel=$_POST['btndel'];
if (isset($btndel)){
	if (isset($id)){
			$qry2 = "DELETE FROM up_files WHERE id=".$id;
			$result2 = $connector->query($qry2);		
			if (!isset($result2)){
				echo "<span class='label label-danger'>Error occured. Please try again</span><br /><br />";
			}
			else {
				echo "<span class='label label-success'>File Deleted</span><br /><br />";
				
			}
	}
	else {
		echo "<span class='label label-warning'>Please select a document to delete before clicking the delete button</span><br /><br />";
	}
}

else {
	echo "<span class='label label-info'>Please select a document to delete before click delete button</span><br /><br />";
}
/*
*/

?>
<div>
<input type='submit' value='Delete' name='btndel' class='btn btn-danger' onclick='myfx()1;' />&nbsp;
<input type="button" value="Upload" class="btn btn-primary" onclick="window.open('upl.php','_self');" />&nbsp;

</div>


</form>
  
  
  
              
  </div>   
  
</div>


</div>

	<div id="footer">
			<div class="left" ><h4>&copy; 2019 Online student clearance system.</h4></div>
	</div>
	
</div> 
</body>
</html>
