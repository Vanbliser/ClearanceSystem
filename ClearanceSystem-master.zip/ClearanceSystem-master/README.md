# ClearanceSystem
This is a demo of a clearance system that me and my team created. 
